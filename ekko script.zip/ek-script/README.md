# Ekko-script
This program is just a small program to shorten brute force sessions on ekko:)
But to be more satisfying results of the brute force. You better interact directly with ekko.
without having to use this ekko script console first: ').
If you find any errors in running our program.:).
ekko is needed for the process of this program :).
